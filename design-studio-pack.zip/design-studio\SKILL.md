---
name: design-studio
description: >-
  Frontend design studio pack. Chains multi-page site architecture, visual art direction, UI motion
  and pre-ship quality verification into one pipeline. Use when the user wants to build, design,
  redesign, restyle, polish or review a website, landing page, hero, marketing page, company site or
  product UI — also when a page is said to look generic, templated, "AI-made" or sloppy, or when the
  user wants animations added, a design audit, or a page to look premium and award-level. Covers
  architecture, typography, color, imagery, motion, responsive behavior and accessibility in HTML,
  React, Vue, Svelte, Astro or Tailwind. Not for backend-only or non-UI tasks.
version: 1.0.0
pack: true
---

# Design Studio

One pack, five specialist skills, one pipeline. This file is the only entry point: it decides which
specialist handles the job. Keep the specialists out of the conversation until this file routes to
them — reading all five at once wastes context and their advice conflicts.

## Paths

Let `<PACK>` be the directory containing this file.

- `<PACK>/skills/design-taste-frontend/` — visual direction (Node scripts)
- `<PACK>/skills/impeccable/` — verification engine (self-contained binary)
- `<PACK>/skills/motion-ref/` — motion reference (13 categories)
- `<PACK>/skills/premium-website/` — multi-page architecture (templates)
- `<PACK>/skills/ui-ux-pro-max/` — design data engine (Python)
- `<PACK>/optional/` — narrow skills, **do not load unless the user names the artifact** (see below)
- `<PACK>/agents/` — four Impeccable helper subagents

**Windows path rule:** on Windows pass absolute `C:/...` paths to `python.exe` and `node.exe`. A
shell-expanded `~/...` is mangled into `C:\c\Users\...` and the script will not be found. `.cmd`
launchers are fine as-is.

## Route the request first

Read **only** the listed files, then follow that specialist's rules for the actual work.

| The job is | Use |
|---|---|
| Multi-page site: company, product, portfolio, org site, 3+ pages | `premium-website` |
| Single surface: landing page, hero, one-pager, product page | `design-taste-frontend` |
| Adding or fixing animation, transitions, micro-interactions | `motion-ref` |
| Review, critique, audit, polish, "does this look right" | `impeccable` |
| Choosing a palette, font pairing, or overall style from data | `ui-ux-pro-max` |

Narrow artifacts — use the `optional/` skill and say which one you are loading:
a banner or ad creative → `optional/banner-design`; a slide deck → `optional/slides` or
`optional/design-system`; brand voice or identity → `optional/brand`; a logo or CIP →
`optional/design`; shadcn/ui or Tailwind component work → `optional/ui-styling`.
**Do not load these speculatively** — their descriptions are broad and they will hijack ordinary
site work.

## The pipeline

Not every job needs every stage. Skip what the request does not need.

**1. Data.** For a new visual world, pull candidate tokens first:
`python <PACK>/skills/ui-ux-pro-max/scripts/search.py "<product type> <industry> <keywords>" --design-system -p "<Project>"`
This returns a style, palette, font pairing and conversion pattern. Treat it as input, not as a
verdict — it narrows the search, it does not make the decision.

**2. Architecture.**
- Multi-page: start from `<PACK>/skills/premium-website/templates/shared-design.css` and
  `shared-main.js`, plus `references/anti-slop-patterns.md`. One shared stylesheet across pages.
- Single page: skip to stage 3.

**3. Art direction.** For public-facing single surfaces, use taste skill:
- `node <PACK>/skills/design-taste-frontend/scripts/draw.mjs --sector <sector>` deals three researched
  directions; pick one, do not average them.
- It requires real pictures from open archives. Images come with credits; surface those credits.
- Needs Node 22+ and a local Chrome / Edge / Chromium.

**4. Motion.** Add motion by scenario, not by decoration. Read only the matching file in
`<PACK>/skills/motion-ref/ref/`:

| 01-loading | 02-button-feedback | 03-text-data | 04-overlay | 05-navigation |
|---|---|---|---|---|
| 06-form-input | 07-scroll | 08-icon | 09-carousel-list | 10-state |
| 11-ambient | 12-data-viz | 13-enter-exit | | |

Every animation must answer a real problem: confirm an action, ease a wait, show hierarchy, or
direct attention. Decorative motion that does none of these is a defect.

**5. Verify before you say it is done.** Run both:
- `<PACK>/skills/impeccable/scripts/impeccable.cmd detect <file-or-dir>` — 61 deterministic rules,
  no API key. Exit 0 clean, 2 findings. Also usable as `detect <url>`.
- `node <PACK>/skills/design-taste-frontend/scripts/inspect.mjs <url | file.html>` — renders at
  1440 / 768 / 390 in a real browser and fails slop patterns.

Impeccable also carries 24 slash-style commands (`init`, `document`, `shape`, `critique`, `audit`,
`polish`, `typeset`, `layout`, `harden`, `animate`, `colorize`, `distill`, `bolder`, `quieter`,
`adapt`, `clarify`, `onboard`, `optimize`, `live`, `generate` and others). Run
`<PACK>/skills/impeccable/scripts/impeccable.cmd help` to list them. `init` writes PRODUCT.md and
should be run once per project so later commands share context.

## Standing rules

- **The brief beats the default.** A pinned aesthetic, era, palette or font wins even when a
  detector flags it as a saturated pattern.
- **Refinement preserves, redesign replaces.** Refining keeps the incumbent identity and everything
  out of scope. Redesigning keeps product truth and function but treats the old look as the
  anti-reference. Never split the difference.
- **Never default to Inter + a purple gradient.** These are the two tells the pack exists to remove.
- **Verify by looking at the rendered result** at the widths it ships at, and batch the fixes.

## Licensing — check before commercial work

| Skill | License | Commercial use |
|---|---|---|
| design-taste-frontend | MIT | Yes |
| impeccable | Apache 2.0 | Yes |
| motion-ref | MIT | Yes |
| premium-website | MIT | Yes |
| **ui-ux-pro-max (+ `optional/`) — CC-BY-NC-4.0** | **No, not without permission** | |

If the deliverable is for a commercial client, exclude `ui-ux-pro-max` and everything in
`optional/`, and pull tokens from the other four instead. Say so to the user rather than shipping it
silently.
