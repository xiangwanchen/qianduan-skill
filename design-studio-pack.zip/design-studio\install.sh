#!/usr/bin/env bash
# design-studio pack installer
#
#   bash install.sh                    auto-detect the agent's skills directory
#   bash install.sh --target DIR       install into DIR/design-studio
#   bash install.sh --with-optional    also promote the 6 optional skills to top level
#   bash install.sh --help
#
# Auto-detection order: WorkBuddy, Claude Code, Codex.
# No bash? Copy the whole design-studio folder into the agent's skills directory by hand.

set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=""
WITH_OPTIONAL=0

usage() { sed -n '2,9p' "${BASH_SOURCE[0]}"; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target)        TARGET="$2"; shift 2 ;;
    --with-optional) WITH_OPTIONAL=1; shift ;;
    -h|--help)       usage; exit 0 ;;
    *) echo "unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

if [[ -z "$TARGET" ]]; then
  for candidate in \
    "${HOME}/.workbuddy/skills" \
    "${HOME}/.claude/skills" \
    "${HOME}/.codex/skills" \
    "${HOME}/.cursor/skills"; do
    if [[ -d "$candidate" ]]; then TARGET="$candidate"; break; fi
  done
fi

if [[ -z "$TARGET" ]]; then
  echo "No skills directory found. Pass one with --target DIR" >&2
  exit 1
fi

DEST="$TARGET/design-studio"
mkdir -p "$DEST"

for item in SKILL.md README.md LICENSE-NOTES.md skills agents optional; do
  cp -r "$SRC/$item" "$DEST/"
done

echo "installed: $DEST"

if [[ $WITH_OPTIONAL -eq 1 ]]; then
  for skill in "$DEST"/optional/*/; do
    name="$(basename "$skill")"
    if [[ -e "$TARGET/$name" ]]; then
      echo "  skipped $name (already present)"
    else
      cp -r "$skill" "$TARGET/$name"
      echo "  promoted $name"
    fi
  done
fi

cat <<'EOF'

Restart your agent — skills load at session start.
Optional six are parked in optional/ on purpose: their descriptions are broad and they hijack
ordinary site work if they sit at top level.
EOF
