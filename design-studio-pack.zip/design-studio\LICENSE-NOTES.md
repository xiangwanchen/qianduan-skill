# Licenses and sources

This pack bundles third-party skills. Their licenses differ, and one of them restricts commercial
use. Read the table before shipping anything for a client.

## Skills

### premium-website
- Source: https://github.com/Sidiora-Labs/ion-agent-harness (`skills/creative/premium-website`)
- License: **MIT** — commercial use allowed, attribution requested
- Author: Ion Agent

### design-taste-frontend (taste skill v2)
- Source: https://github.com/Leonxlnx/taste-skill (v2.1.5)
- License: **MIT** — commercial use allowed
- Note: retrieves pictures and footage from open archives (Wikimedia Commons, Openverse, the Met,
  NASA, Prelinger). Those assets carry their own CC licenses and the skill writes credits onto the
  page. Replace them with your own imagery where possible.

### motion-ref
- Source: https://github.com/joepUI/motion-ref-skill
- License: **MIT** — commercial use allowed
- Author: joepUI

### impeccable
- Source: https://github.com/pbakaus/impeccable (skill v4.8.0, engine v0.1.18)
- License: **Apache 2.0** — commercial use allowed
- Author: Paul Bakaus / Renaissance Geek
- Note: ships a prebuilt binary in `skills/impeccable/scripts/bin/`. Telemetry is off by default in
  this copy; toggle with `impeccable telemetry on|off`.

### ui-ux-pro-max ⚠️
- Source: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
- License: **CC-BY-NC-4.0 — NON-COMMERCIAL. Commercial use is NOT permitted without the author's
  permission.**
- Applies to: `skills/ui-ux-pro-max/` and **all six skills in `optional/`**
  (banner-design, brand, design, design-system, slides, ui-styling)

## What to do for commercial work

Delete these two paths from the pack:

```
skills/ui-ux-pro-max/
optional/
```

The remaining four are MIT or Apache 2.0 and cover architecture, direction, motion and verification
without them. The router in `SKILL.md` will fall through cleanly — it never depends on the
non-commercial data engine to function.

## Upstream

Versions are frozen as of 2026-10-31. Each project updates independently; refresh them from their own
repositories rather than treating this pack as a distribution channel.
